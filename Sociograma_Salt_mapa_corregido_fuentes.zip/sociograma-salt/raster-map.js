/* Small DOM raster map. Street tiles are ordinary images: no WebGL or worker.
 * Web Mercator / XYZ, north up. Requests only tiles in the visible viewport;
 * browser HTTP caching is used, without prefetch or offline tile downloads.
 */
(() => {
  'use strict';
  const size = z => 256 * 2 ** z;
  function project(lon, lat, z) {
    const s = size(z), p = Math.max(-85.05112878, Math.min(85.05112878, lat)) * Math.PI / 180;
    return [(lon + 180) / 360 * s, (1 - Math.log(Math.tan(p) + 1 / Math.cos(p)) / Math.PI) / 2 * s];
  }
  function unproject(x, y, z) {
    const s = size(z);
    return [x / s * 360 - 180, Math.atan(Math.sinh(Math.PI * (1 - 2 * y / s))) * 180 / Math.PI];
  }
  function tileCoverage(center, zoom, width, height) {
    const z = Math.floor(zoom), scale = 2 ** (zoom - z), p = project(...center, zoom);
    const left = p[0] - width / 2, top = p[1] - height / 2, tileSize = 256 * scale;
    const result = [];
    for (let y = Math.floor(top / tileSize); y <= Math.floor((top + height - 1) / tileSize); y++) {
      for (let x = Math.floor(left / tileSize); x <= Math.floor((left + width - 1) / tileSize); x++) {
        if (x < 0 || y < 0 || x >= 2 ** z || y >= 2 ** z) continue;
        result.push({key: `${z}/${x}/${y}`, x: x * tileSize - left, y: y * tileSize - top, size: tileSize});
      }
    }
    return result;
  }
  class SaltRasterMap {
    constructor(el, options = {}) {
      this.el = el;
      this.center = options.center || [2.7893, 41.974];
      this.zoom = options.zoom || 15;
      this.onStatus = options.onStatus || (() => {});
      this.tiles = new Map(); this.visible = []; this.pointers = new Map();
      this.width = 0; this.height = 0; this.drawOverlay = () => '';
      this.frame = 0; this.dragged = false;
      el.classList.add('raster-map'); el.tabIndex = 0;
      el.setAttribute('role', 'region');
      el.setAttribute('aria-label', 'Mapa de carrers OpenStreetMap. Fletxes per desplaçar; + i − per ampliar.');
      el.innerHTML = '<div class="raster-tiles" aria-hidden="true"></div><svg class="raster-overlay" xmlns="http://www.w3.org/2000/svg"></svg><div class="raster-controls"><button data-map-zoom="1" aria-label="Amplia el mapa">+</button><button data-map-zoom="-1" aria-label="Redueix el mapa">−</button></div><div class="raster-scale" aria-hidden="true"></div><div class="raster-attribution">© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap contributors</a></div>';
      this.tilePane = el.querySelector('.raster-tiles');
      this.svg = el.querySelector('svg'); this.scaleEl = el.querySelector('.raster-scale');
      el.addEventListener('click', e => {
        if (this.dragged) { e.preventDefault(); e.stopImmediatePropagation(); this.dragged = false; return; }
        const button = e.target.closest('[data-map-zoom]');
        if (button) { this.zoomAt(this.zoom + Number(button.dataset.mapZoom), this.width / 2, this.height / 2); e.stopPropagation(); }
      }, true);
      const local = e => { const b = el.getBoundingClientRect(); return [e.clientX - b.left, e.clientY - b.top]; };
      el.addEventListener('pointerdown', e => {
        if (e.target.closest('button,a') || (e.pointerType === 'mouse' && e.button !== 0)) return;
        this.dragged = false; this.pointers.set(e.pointerId, local(e));
        // Delay capture until a drag starts, so a marker tap keeps its target.
      });
      el.addEventListener('pointermove', e => {
        if (!this.pointers.has(e.pointerId)) return;
        const before = [...this.pointers.values()], previous = this.pointers.get(e.pointerId), next = local(e);
        const dx = next[0] - previous[0], dy = next[1] - previous[1];
        if (!this.dragged && Math.hypot(dx, dy) < 3) return;
        this.dragged = true; el.setPointerCapture(e.pointerId); this.pointers.set(e.pointerId, next);
        if (this.pointers.size === 2) {
          const after = [...this.pointers.values()];
          const d0 = Math.hypot(before[0][0] - before[1][0], before[0][1] - before[1][1]);
          const d1 = Math.hypot(after[0][0] - after[1][0], after[0][1] - after[1][1]);
          const mid = [(after[0][0] + after[1][0]) / 2, (after[0][1] + after[1][1]) / 2];
          if (d0 > 0 && d1 > 0) this.zoomAt(this.zoom + Math.log2(d1 / d0), ...mid);
          this.pan(dx / 2, dy / 2);
        } else this.pan(dx, dy);
        e.preventDefault();
      });
      const release = e => { this.pointers.delete(e.pointerId); if (el.hasPointerCapture(e.pointerId)) el.releasePointerCapture(e.pointerId); };
      el.addEventListener('pointerup', release); el.addEventListener('pointercancel', release);
      el.addEventListener('pointerleave', e => { if (!el.hasPointerCapture(e.pointerId)) this.pointers.delete(e.pointerId); });
      el.addEventListener('wheel', e => {
        e.preventDefault(); this.zoomAt(this.zoom + (e.deltaY < 0 ? 0.5 : -0.5), ...local(e));
      }, {passive:false});
      el.addEventListener('dblclick', e => { if (!e.target.closest('button,a,[data-open],[data-group]')) this.zoomAt(this.zoom + 1, ...local(e)); });
      el.addEventListener('keydown', e => {
        if (e.target !== el) return;
        const moves = {ArrowLeft:[100,0],ArrowRight:[-100,0],ArrowUp:[0,100],ArrowDown:[0,-100]};
        if (moves[e.key]) { e.preventDefault(); this.pan(...moves[e.key]); }
        if (['+','=','-','−'].includes(e.key)) { e.preventDefault(); this.zoomAt(this.zoom + (['-','−'].includes(e.key) ? -1 : 1), this.width/2, this.height/2); }
      });
      if (window.ResizeObserver) { this.observer = new ResizeObserver(() => this.resize()); this.observer.observe(el); }
      this.resize();
      this.loadingTimer = setTimeout(() => this.status(true), 12000);
    }
    resize() { this.width = this.el.clientWidth; this.height = this.el.clientHeight; this.schedule(); }
    schedule() { if (this.frame) return; this.frame = requestAnimationFrame(() => { this.frame = 0; this.render(); }); }
    getZoom() { return this.zoom; }
    project(coordinate) {
      const p = project(...coordinate, this.zoom), c = project(...this.center, this.zoom);
      return {x:p[0]-c[0]+this.width/2, y:p[1]-c[1]+this.height/2};
    }
    easeTo({center = this.center, zoom = this.zoom}) { this.center = center; this.zoom = Math.max(10,Math.min(19,zoom)); this.schedule(); }
    pan(dx,dy) { const c = project(...this.center, this.zoom); this.center = unproject(c[0]-dx,c[1]-dy,this.zoom); this.schedule(); }
    zoomAt(zoom,x,y) {
      zoom = Math.max(10,Math.min(19,zoom));
      const c = project(...this.center,this.zoom), anchor = unproject(c[0]+x-this.width/2,c[1]+y-this.height/2,this.zoom);
      const q = project(...anchor,zoom);
      this.center = unproject(q[0]-x+this.width/2,q[1]-y+this.height/2,zoom); this.zoom = zoom; this.schedule();
    }
    setOverlay(fn) { this.drawOverlay = fn; this.schedule(); }
    status(timeout = false) {
      if (!this.visible.length) return;
      const loaded = this.visible.filter(t => this.tiles.get(t.key)?.dataset.status === 'loaded').length;
      const failed = this.visible.filter(t => this.tiles.get(t.key)?.dataset.status === 'error').length;
      this.onStatus({loaded,total:this.visible.length,failed,timeout});
    }
    retry() {
      for (const [key,img] of this.tiles) if (img.dataset.status !== 'loaded') { img.remove(); this.tiles.delete(key); }
      this.render();
    }
    render() {
      if (!this.width || !this.height) return;
      this.visible = tileCoverage(this.center,this.zoom,this.width,this.height);
      const keys = new Set(this.visible.map(t => t.key));
      for (const [key,img] of this.tiles) img.hidden = !keys.has(key);
      for (const tile of this.visible) {
        let img = this.tiles.get(tile.key);
        if (!img) {
          img = document.createElement('img'); img.alt = ''; img.draggable = false;
          img.crossOrigin = 'anonymous'; img.referrerPolicy = 'strict-origin-when-cross-origin'; img.dataset.status = 'loading';
          img.onload = () => { img.dataset.status = 'loaded'; this.status(); };
          img.onerror = () => { img.dataset.status = 'error'; this.status(); };
          this.tiles.set(tile.key,img); this.tilePane.append(img);
          img.src = 'https://tile.openstreetmap.org/' + tile.key + '.png';
        }
        img.hidden = false; img.style.transform = `translate(${tile.x}px,${tile.y}px)`;
        img.style.width = img.style.height = (tile.size + 0.3) + 'px';
      }
      // Bound DOM memory while retaining recently viewed images. The browser
      // manages its own HTTP cache; no tile data is stored by the application.
      for (const [key,img] of this.tiles) if (this.tiles.size > 120 && !keys.has(key)) { img.remove(); this.tiles.delete(key); }
      this.svg.setAttribute('viewBox',`0 0 ${this.width} ${this.height}`);
      this.svg.innerHTML = this.drawOverlay(this);
      const metersPerPixel = 40075016.686 * Math.cos(this.center[1]*Math.PI/180) / size(this.zoom);
      const scaleMeters = [20,50,100,200,500,1000,2000,5000].filter(n => n/metersPerPixel < 110).pop() || 20;
      this.scaleEl.style.width = (scaleMeters/metersPerPixel)+'px';
      this.scaleEl.textContent = scaleMeters >= 1000 ? scaleMeters/1000+' km' : scaleMeters+' m';
      this.status();
    }
    async exportCanvas() {
      if (this.visible.some(t => this.tiles.get(t.key)?.dataset.status !== 'loaded')) throw new Error('Espera que es carregui tot el mapa de carrers abans d’exportar.');
      const c = document.createElement('canvas'); c.width = this.width*2; c.height = this.height*2;
      const ctx = c.getContext('2d'); ctx.scale(2,2);
      for (const t of this.visible) ctx.drawImage(this.tiles.get(t.key),t.x,t.y,t.size+0.3,t.size+0.3);
      const svg = this.svg.cloneNode(true); svg.setAttribute('width',this.width); svg.setAttribute('height',this.height);
      const image = new Image();
      await new Promise((resolve,reject) => { image.onload = resolve; image.onerror = reject; image.src = 'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(new XMLSerializer().serializeToString(svg)); });
      ctx.drawImage(image,0,0,this.width,this.height); return c;
    }
  }
  window.SaltRasterMap = SaltRasterMap;
  window.SaltMercator = {project,unproject,tileCoverage};
})();
