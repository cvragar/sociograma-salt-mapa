# Sociograma comunitario de Salt · corrección del mapa y de las conexiones

Revisión selectiva de fuentes: **8 de octubre de 2026**. Interfaz en catalán, como la base aportada.

## Abrir y utilizar

- Abre `index.html` en un navegador actual. El paquete no requiere instalación ni compilación.
- La entrega incluye también `Sociograma_Salt_mapa_corregido.html`, una copia autónoma con datos, estilos y bibliotecas integrados.
- **Mapa:** busca un recurso, filtra por ámbito y abre su ficha. Los puntos coincidentes se agrupan. Las fichas sin coordenadas siguen disponibles en la lista y el directorio.
- **Xarxa:** abre inicialmente el entorno de la Comisión de Salud Comunitaria. Conserva visibles fuentes públicas, internas, pertenencias y las hipótesis, con estilos diferenciados. «Explora vincles» centra la red en cualquier ficha. «Xarxa completa» incluye los 495 vínculos; las 7 fichas sin ningún vínculo recogido aparecen en un apartado explicativo. Al filtrar por ámbito se mantienen sus conexiones con actores de otros ámbitos.
- **Directori:** incluye todas las fichas y un anexo consultable del registro municipal.
- **Planifica:** seis propuestas iniciales, selección de actores, objetivo, población, espacio, coordinación e indicadores. Exporta el plan a HTML para imprimir o a JSON para recuperarlo. El guardado del navegador no sincroniza entre dispositivos ni sustituye una copia exportada.
- **Fonts i revisió:** consulta procedencia, cambios, limitaciones y prioridades de validación. Exporta datos y pendientes a CSV.

El fondo de calles de **OpenStreetMap está activo desde el inicio** y requiere conexión. Se muestra mediante imágenes de teselas y una capa SVG de coordenadas, sin WebGL ni workers. Ya no se sustituye por un esquema sin calles. Se puede desplazar, ampliar con rueda, pinza o botones, centrar Salt y seleccionar puntos; los controles de teclado permiten usar flechas y +/−. Los puntos coincidentes muestran el número de fichas.

Al abrir una ficha, el mapa destaca sus vínculos con ubicaciones conocidas. No se inventan coordenadas para programas sin sede; sus conexiones completas se consultan en la red y en la ficha. Las líneas representan relaciones, no trayectos. Un fallo de carga del fondo muestra un aviso y un botón de reintento. La exportación PNG del mapa exige haber cargado las teselas y mantiene la atribución.

Descarga el HTML y ábrelo en un navegador. Un visor de archivos que impida conexiones externas puede bloquear las calles. La red, los datos, el directorio y el planificador están integrados en el archivo. No se descargan teselas para uso sin conexión.

## Alcance y contenido

El ámbito de planificación es Salt urbano y los CAP Salt 1 —Jordi Nadal— y Salt 2 —Alfons Moré—. No se incluyen los consultorios rurales como población diana. Se conserva la dirección del EAP como interlocutor de coordinación y los recursos externos que pueden dar servicio a Salt.

La base contiene **267 fichas**, **495 relaciones**, **121 fichas geolocalizadas**, **204 entradas registrales complementarias**, **19 fuentes consultadas en esta revisión** y **69 cambios registrados**. Las fichas incluyen actores, colectivos, servicios, programas e instrumentos: no son 267 entidades únicas. El anexo registral puede coincidir con el sociograma y no debe sumarse al total como entidades nuevas.

De las 495 relaciones, 345 citan fuentes públicas, 2 combinan públicas e internas, 91 dependen de fuentes internas y 57 son hipótesis. «Fuente pública citada» describe su procedencia; no significa que todas esas relaciones hayan sido revalidadas en octubre de 2026. Las fechas y la revisión actual se guardan por separado.

Cambios destacados: BULL-S con su referencia propia y aplicación local pendiente; Salt'Educa localizable también como SaltT'educa; Oncolliga separada de AECC; Resilis separada de Utopia; ANNCON reclasificada como empresa prestadora; actualización de participación en la Taula d'Acollida; TALC 2026-2027, Rossinyol, TSAE, Kayak a l'Aula, Neda a l'escola y asesoramiento energético añadidos o detallados.

## Límites que condicionan la planificación

1. **Adscripción de Salt 1 y Salt 2:** no se ha obtenido un callejero/UBA o polígono oficial que divida ambos ámbitos. Los antiguos polígonos por proximidad no se usan. Los círculos de 500 y 1.000 metros son distancias en línea recta, no zonas sanitarias ni tiempos a pie. Tampoco se asignan al municipio cifras de población de todo el EAP.
2. **BULL-S:** se documenta el instrumento; no se ha acreditado su implantación en centros de Salt. Confirmar centros, cursos, responsable, versión y circuito con los equipos educativos antes de planificar su uso. No se almacenan datos de alumnado.
3. **Documentación interna:** los ZIP citan memoria anual, comunicación personal y material interno que no estaba disponible para contrastar íntegramente. Sus vínculos se identifican en naranja y pueden desactivarse explícitamente.
4. **Actualidad:** la revisión es selectiva. Horarios, plazas, costes, idiomas, accesibilidad, continuidad de A-Porta/Citizen Doors y actividades del CAP requieren confirmación con sus responsables. SAFIS se contrastó con texto indexado; el sitio no permitió lectura íntegra. Algunas páginas educativas describen ofertas antiguas cuyo curso actual no está confirmado.
5. **Cartografía:** límites y secciones INE heredados, con IST 2023 de la base. El IST no se presenta como la última estadística disponible ni como una característica de personas o comunidades.
6. **Participación:** las propuestas y equipos sugeridos no representan acuerdos con entidades. La ausencia de un vínculo en el mapa no indica aislamiento real. El sociograma necesita devolución y validación con vecindario organizado y no organizado, escuelas, entidades y profesionales.

## Publicar en el repositorio existente

Esta entrega **no modifica** la web pública de GitHub Pages. El paquete es estático y compatible con ese alojamiento.

1. Conserva una copia de la versión publicada y trabaja en una rama del repositorio `sociograma-salt`.
2. Coloca el contenido de esta carpeta en el directorio desde el que ya publica GitHub Pages, conservando su configuración de publicación y cualquier dominio personalizado.
3. Revisa el cambio y prueba mapa, fichas, red, filtros y exportaciones en escritorio y móvil. Comprueba especialmente los puntos de ambos CAP y una entidad con varios recursos en la misma sede.
4. Integra el cambio mediante el procedimiento habitual del repositorio. Si Pages publica una carpeta específica, estos archivos deben estar dentro de esa carpeta.

Como alternativa de revisión, abre el HTML autónomo sin cambiar el sitio publicado. Para compartir enlaces de filtros entre personas, usa la dirección web publicada; un enlace `file://` solo apunta al equipo local.

## Archivos y mantenimiento

- `index.html`, `style.css`, `app.js`: interfaz y funciones.
- `raster-map.js`: mapa de teselas OSM y proyección Web Mercator, sin bibliotecas gráficas externas.
- `data/base/`: copia sin editar de los cuatro CSV de entrada; material heredado.
- `data/*.json`, `data/dades.js`: base de trabajo y datos integrados en el navegador.
- `descarregues/`: CSV actualizados, fuentes revisadas y registro de cambios.
- `scripts/build_data.py`: transformaciones reproducibles sobre la copia de entrada.
- `scripts/check.js` y `scripts/validate.py`: 39 comprobaciones de lógica, proyección, carga de teselas simulada, filtros y relaciones. Usan JavaScriptCore, un DOM simulado y Cytoscape real sin navegador.
- `scripts/package.py`: genera el HTML autónomo y el ZIP.
- `VALIDACION.json`: resultado de las comprobaciones ejecutadas.
- `lib/`: bibliotecas locales y sus licencias, conservadas del visor aportado.

Para regenerar después de un cambio documentado:

```sh
python3 scripts/build_data.py
python3 scripts/package.py
```

Los cambios de fuentes deben incluir fecha de consulta, evidencia concreta y alcance de lo que confirman. Si se cambia la fecha de revisión, también deben actualizarse los textos de la interfaz; no basta con cambiar una etiqueta para considerar vigente un dato.

## Validación de esta corrección

Se han ejecutado **39 comprobaciones de lógica e integración simulada**. Incluyen reproyección, cobertura del encuadre por las teselas, zoom anclado al cursor, desplazamiento conjunto de calles y puntos, cambio de tamaño, fallo y reintento de teselas, recursos coincidentes, los filtros y las conexiones de Salt'Educa y BULL-S. El fallo anterior de 101 fichas aisladas por filtros se reproduce en la prueba; con todos los vínculos se conservan 260 fichas conectadas y 7 sin relación recogida. Los datos de la versión recibida (267 fichas y 495 vínculos) no se han alterado.

**No se ha podido comprobar la visualización ni descargar las teselas en un navegador real de esta sesión.** El dominio de la web original está bloqueado por una preferencia guardada de permisos; también está restringida la previsualización local. Se ha leído y comparado la copia original adjunta. Por ello no se afirman pruebas visuales, de gestos en un dispositivo real o de exportación PNG completadas. La web pública de GitHub no se ha modificado.

Para repetir las comprobaciones en macOS:

```sh
python3 scripts/validate.py
python3 scripts/package.py
```

La interfaz mantiene los colores, la cabecera y la organización visual de la versión 2. Esta corrección se centra en la comprensión del mapa y de las relaciones, sin inventar nuevos vínculos ni modificar las fuentes.

Cytoscape conserva su licencia en `lib/`. El fondo está atribuido a OpenStreetMap y respeta su URL XYZ y caché HTTP del navegador, sin precarga de áreas. Referencia: https://operations.osmfoundation.org/policies/tiles/. La cartografía local y las fuentes mantienen su atribución en los datos.
