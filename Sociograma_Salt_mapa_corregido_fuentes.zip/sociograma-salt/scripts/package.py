"""Build a portable HTML and a source ZIP. No network or installed packages."""
from pathlib import Path
import re
import json
import zipfile
import hashlib
from html.parser import HTMLParser

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT.parent / 'entrega-mapa'
OUT.mkdir(exist_ok=True)
NAME = 'Sociograma_Salt_mapa_corregido'
html = (ROOT / 'index.html').read_text()

class References(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []
        self.refs = []
    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if 'id' in a:
            self.ids.append(a['id'])
        for key in ('src', 'href'):
            if key in a and not a[key].startswith(('http:', 'https:', '#', 'data:')):
                self.refs.append(a[key])

parser = References()
parser.feed(html)
assert len(parser.ids) == len(set(parser.ids)), 'duplicate DOM ID'
assert all((ROOT / p).is_file() for p in parser.refs), 'missing local asset'

def style(m):
    return '<style>\n' + (ROOT / m[1]).read_text().replace('</style', '<\\/style') + '\n</style>'

def script(m):
    return '<script>\n' + (ROOT / m[1]).read_text().replace('</script', '<\\/script') + '\n</script>'

portable = re.sub(r'<link rel="stylesheet" href="([^"]+)">', style, html)
portable = re.sub(r'<script src="([^"]+)"></script>', script, portable)
licenses = '\n'.join((ROOT / 'lib' / x).read_text() for x in ('LICENSE-cytoscape.txt',))
portable = portable.replace('</body>', '<!-- Bundled library licenses\n' + licenses.replace('--', '—') + '\n-->\n</body>')
portable_parser = References()
portable_parser.feed(portable)
assert not portable_parser.refs, 'portable HTML retains external file dependency'
assert len(re.findall(r'</script\s*>', portable, re.I)) == 4, 'unsafe embedded script delimiter'
target = OUT / (NAME + '.html')
target.write_text(portable)
(ROOT / '.nojekyll').touch()
zip_path = OUT / (NAME + '_fuentes.zip')
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and p.name != '.DS_Store':
            z.write(p, Path('sociograma-salt') / p.relative_to(ROOT))
    z.write(target, target.name)
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None, 'corrupted archive'
print(json.dumps({'html': str(target), 'html_bytes': target.stat().st_size,
                  'zip': str(zip_path), 'zip_bytes': zip_path.stat().st_size,
                  'local_references': len(parser.refs),
                  'sha256_html': hashlib.sha256(target.read_bytes()).hexdigest()}, ensure_ascii=False))
