"""Rebuild the public-source working dataset without editing the supplied base."""
import csv, json, re, math, copy
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'data/base'
TODAY = '2026-10-08'
def read_csv(name):
    with (BASE/name).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))
A = read_csv('actors.csv')
R = read_csv('relacions.csv')
F = read_csv('fonts.csv')
registry = read_csv('registre_entitats_salt_annex.csv')
byid = {a['id']:a for a in A}
changes = []
fresh = []

def source(key, title, url, date, finding):
    s = dict(clau=key, titol=title, url=url, data_publicacio=date, consulta=TODAY, constatacio=finding)
    fresh.append(s)
    F.append(dict(clau=key, url=url, data=TODAY, descripcio=title))
    return url

ICS = source('REV_ICS', 'ICS Girona · projecte CSIR de Salt', 'https://icsgirona.cat/htrueta/ca/actualitat/lequip-datencio-primaria-de-salt-comenca-implantar-el-seu-projecte-com-csir-la-llavor-de', '2025-07-09', "Un EAP amb dos CAP urbans i quatre consultoris rurals. Les xifres de tot l'EAP no són les del municipi.")
ACOLL = source('REV_ACOLLIDA', "Resilis · Taula d'Acollida 2026", 'https://www.resilis.org/primera-taula-dacollida-de-2026-a-salt/', '2026-02-25', "Participació explícita de Resilis i llista d'entitats participants. No equival a conveni bilateral entre totes elles.")
EDU = source('REV_PROJECTES', 'Educació Salt · projectes educatius', 'https://educacio.viladesalt.cat/pla-educatiu-de-salt/projectes-educatius/', 'pàgina actualitzada 2026-07-31', 'Catàleg municipal; cada curs i les places disponibles es confirmen amb el servei.')
CENTRES = source('REV_CENTRES', 'OME · mapa de centres educatius', 'https://educacio.viladesalt.cat/ome/mapa-de-centres-educatius-de-salt/', 'pàgina sense confirmació global del curs 2026-27', 'Directori educatiu municipal consultat; no pressuposa que tots els programes siguin presents a cada centre.')
SIGUES = source('REV_SIGUES', 'Educació Salt · Sigues Tu', 'https://educacio.viladesalt.cat/sigues-tu/', '2023-11-16', 'Programa de Dipsalut per treballar habilitats per a la vida; no prova implantació a tots els centres de Salt.')
SALT = source('REV_SALTEDUCA', "Salt'Educa · plataforma ciutadana", 'https://salteduca.org/', 'web amb accions 2017-2023; sense data global', "Finalitat contra la segregació escolar, assemblees a la Coma Cros i correu públic. No valida totes les adhesions de 2017 el 2026.")
CEM = source('REV_PARTICIPACIO', 'Educació Salt · espais de participació', 'https://educacio.viladesalt.cat/espais-de-participacio/', '2023-10-10', 'CEM, grup motor, comissions i Taula Formació i Laboral.')
FIL = source('REV_FIL', 'Educació Salt · Taula Formació i Laboral', 'https://educacio.viladesalt.cat/espais-de-participacio/taula-formacio-i-laboral-fil/', 'sense data visible', 'Identitat pública de la Taula FiL; la participació concreta del CAP queda sustentada només per la base interna rebuda.')
BULL = source('REV_BULLS', 'Cerezo · Test Bull-S, actualització', 'https://revista.infad.eu/index.php/IJODAEP/article/view/774', '2014-01-30', "Instrument d'avaluació sociomètrica de l'assetjament dins del grup aula. La publicació no documenta aplicació a Salt.")
AQUI = source('REV_AQUIPROU', 'XTEC · #aquiproubullying', 'https://xtec.gencat.cat/ca/centres/projeducatiu/convivencia/aquiproubullying/', 'actualització 2026-06-01', 'Programa educatiu vigent al web de XTEC; llistat local i curs a confirmar.')
AECC = source('REV_AECC', 'Associació Contra el Càncer · seu de Girona', 'https://www.contraelcancer.es/es/sobre-nosotros/donde-estamos/sede-girona', 'sense data global visible', 'Entitat diferenciada d’Oncolliga. Seu pública i contacte: Eiximenis 18, Girona; girona@contraelcancer.es; 972 20 13 06.')
PV = source('REV_PV', 'Punt de Voluntariat · entitats de Salt', 'https://puntvoluntariat.viladesalt.cat/les-entitats-de-salt/', 'sense data global visible', 'Catàleg de portes d’entrada al voluntariat; inclou Oncolliga, DOTA, Casal dels Infants i El Prestatge.')
SAFIS = source('REV_SAFIS', 'Infosalt · balanç SAFIS 2026', 'https://www.infosalt.cat/mes-de-3-500-persones-participen-en-les-activitats-de-les-setmanes-de-lactivitat-fisica-i-la-salut-2026-a-salt/', 'edició 2026; data exacta no comprovada', "Consulta del text indexat; la lectura íntegra del web ha quedat bloquejada. Activitat ja celebrada. Llista de col·laboradors que permet acreditar participació en l'esdeveniment, no una aliança estable.")
IFBS = source('REV_METODE', 'IFBS · el sociograma (Alberich)', 'https://www.ifbscalidad.eus/es/practicas/accion-comunitaria/practica/pr-1190/', 'manual de referència 2009', 'Actors, relacions i validació participativa. La geometria de la xarxa no mesura poder ni legitimitat.')
TALC = source('REV_TALC', 'Formació Adults Salt · TALC 2026-2027', 'https://formacioadults.viladesalt.cat/events/tallers-dacollida-linguistica-i-cultural-talc', 'curs 2026-2027', 'Oferta anunciada per al curs 2026-2027; inscripció ordinària de setembre ja passada, places actuals a consultar.')
APORTA = source('REV_APORTA', 'CONFAVC · Citizen Doors a Salt', 'https://confavc.cat/noticies/citizen-doors_salt/', '2026-07-21', 'Balanç de la primera fase i anunci de nova missió a partir de setembre. La notícia no acredita el desplegament efectiu després de setembre.')
ROSS = source('REV_ROSSINYOL', 'Educació Salt · Mentoria social / Rossinyol', 'https://educacio.viladesalt.cat/projecte-mentoria-rossinyol/', 'publicada 2023-11-16; actualització indicada 2026-02-18', 'Mentoria amb alumnat universitari i col·laboració de la Fundació Girona Regió del Coneixement. Places del curs actual a confirmar.')
TSAE = source('REV_TSAE', 'Educació Salt · Tallers de Suport i Acompanyament Educatiu', 'https://educacio.viladesalt.cat/pla-educatiu-de-salt/projectes-educatius/tallers-destudi-assistit-i-suport-diversificat/', '2025-05-13', 'Programa extraescolar vinculat al PEE/PMOE, amb escoles i instituts. La font descriu participació general però no detalla grups 2026-27.')
KAYAK = source('REV_KAYAK', 'Educació Salt · Kayak a l’Aula', 'https://educacio.viladesalt.cat/kayak-a-laula/', '2023-11-16', 'Oferta municipal per a sisè de primària als centres que hi vulguin participar. Calendari i adhesions actuals no especificats.')

def patch(id, why, src=None, **fields):
    a = byid[id]
    for key,val in fields.items():
        if a.get(key) != val:
            changes.append(dict(tipus='actor', id=id, camp=key, anterior=a.get(key,''), nou=val, motiu=why, font=src or '', data=TODAY))
            a[key] = val
    if src:
        a['fonts_revisades'] = list(dict.fromkeys(a.get('fonts_revisades',[]) + [src]))
        a['revisio_actual'] = TODAY
        if src not in a['font_url']: a['font_url'] += ' | ' + src

patch('E09', 'La font anterior corresponia a Alberich, no a BULL-S.', BULL,
      nom="BULL-S · instrument sociomètric (aplicació a Salt pendent)",
      font_url=BULL, claus_fonts='REV_BULLS', data_font='2014-01-30; consulta 2026-10-08',
      rol_potencial="Eina d'avaluació del grup aula. Valorar-ne l'ús amb l'EAP psicopedagògic i els centres educatius; confirmar versió, responsable, centres i cursos abans d'incorporar-lo a un programa local.",
      estat_verificacio='aplicació local no acreditada', categoria_node='instrument',
      nota="No és una entitat ni un programa implantat acreditat. No s'hi recullen resultats ni dades d'alumnes.")
patch('E08', 'Separar existència del programa i implantació local actual.', AQUI,
      estat_verificacio='implantació local 2026-27 pendent',
      nota="La base cita seguiment del PES 2021-22. Confirmar centres participants i continuïtat el curs 2026-27.")
patch('E43', 'Identitat i contacte públic revisats.', SALT, web_contacte_public='https://salteduca.org/ · peducaciosalt@gmail.com', aliases="SaltT'educa; Salt'Educa; Salt Educa")
patch('E03', 'Nom del recurs públic municipal.', CEM, nom='Consell Educatiu Municipal (CEM) i grups de treball')
patch('E10', 'El catàleg confirma el recurs, no tots els centres participants.', SIGUES,
      nota='Oferta municipal documentada. Confirmar adhesió i calendari de cada centre per al curs 2026-27.')
patch('SS30', 'La font municipal desplega la sigla FiL.', FIL, nom='Taula de Formació i Laboral (FiL) de Salt',
      rol_potencial="Coordinació de l'orientació educativa i laboral. La participació de l'EAP que consta a la base prové de la Memòria 2025 no aportada en aquesta revisió.")
patch('SS26', 'Taula documentada en una reunió de 2026.', ACOLL, web_contacte_public='acollida@salt.cat',
      rol_potencial="Espai de coordinació d'acollida amb administració i tercer sector. Porta d'entrada per contrastar barreres d'accés i codissenyar accions.")
patch('T26', 'Desagregar Utopia i Resilis per no atribuir relacions indistintament.', ACOLL,
      nom='Fundació Resilis', web_contacte_public='https://www.resilis.org/',
      rol_potencial="Participa a la Taula d'Acollida de Salt el febrer de 2026. Agent per al treball amb infància, adolescència i acollida.",
      font_url=ACOLL+' | https://entitats.salt.cat/entitat/fundaci%c2%a2-privada-resilis/',
      nota="Separada de Fundació Utopia en aquesta revisió. Adreça i coordenades heretades del directori; confirmar lloc d'atenció.")
patch('T17', 'Oncolliga i AECC són entitats diferents.', PV,
      nom='Fundació Oncolliga Girona', web_contacte_public='https://oncolligagirona.cat/',
      nota="Les relacions antigues que deien explícitament AECC s'han traslladat a T31. Presència al catàleg de voluntariat; disponibilitat local a confirmar.")
patch('T30', 'ANNCON és una societat mercantil, no una entitat del tercer sector.', None,
      esfera='Serveis municipals i socials', ambit='empresa prestadora/infància', categoria_node='empresa',
      nota="Adjudicació de 2024 recollida a la base. Continuïtat contractual el 08/10/2026 a confirmar amb l'Ajuntament.")
patch('X09', "No traslladar una xifra de tot l'EAP a Salt urbà.", ICS,
      nom='Persones amb cronicitat complexa i necessitats de suport',
      nota="La xifra d'uns 1.600 pacients d'alt risc publicada el 2025 correspon al conjunt de l'EAP, inclosos els pobles. No s'utilitza com a població diana de Salt 1 i Salt 2.")
patch('X04', 'Evitar convertir una observació antiga en atribut de tot un col·lectiu.', None,
      nom='Veïnat gitano no vinculat a entitats',
      rol_potencial='Participació directa en la diagnosi i el disseny de les accions comunitàries.',
      nota="La referència a absentisme és històrica (2017-18). No permet atribuir necessitats actuals a tot el col·lectiu; escoltar i validar amb les persones participants.")
patch('S01', 'No presentar estimacions antigues com a població actual del CAP.', ICS,
      rol_potencial='CAP urbà de referència. Punt de coordinació i de captació per a activitats comunitàries del municipi; confirmar població adscrita i circuits amb l’equip.')
patch('S02', 'Focalitzar el recurs en Salt urbà.', ICS,
      rol_potencial='CAP urbà de referència. Punt de coordinació i de captació per a activitats comunitàries del municipi.')
patch('T01', 'Oferta lingüística amb convocatòria del curs actual.', TALC)
patch('SS23', 'Revisió de participació publicada en les SAFIS 2026.', SAFIS)
patch('C23', 'Distingir balanç real i continuïtat anunciada.', APORTA,
      nota="La font del 21/07/2026 documenta visites a 821 llars i anuncia Citizen Doors per al setembre. No acredita l'inici efectiu de la nova fase; confirmar continuïtat i cobertura actuals.")

def add_actor(template, id, **fields):
    a=copy.deepcopy(byid[template]);a.update(fields);a['id']=id
    a['revisio_actual']=fields.get('revisio_actual',TODAY)
    a['fonts_revisades']=fields.get('fonts_revisades',[a['font_url']])
    A.append(a);byid[id]=a
    changes.append(dict(tipus='nou_actor',id=id,motiu=a['nota'],data=TODAY))
add_actor('T17','T31',nom='Associació Contra el Càncer a Girona (AECC)',
          font_url=AECC,claus_fonts='REV_AECC',data_font='consulta 2026-10-08',
          adreca='C/ Eiximenis, 18, Girona',lat='',lon='',precisio_geo='',
          web_contacte_public='https://www.contraelcancer.es/es/sobre-nosotros/donde-estamos/sede-girona · girona@contraelcancer.es · 972 20 13 06',
          rol_potencial='Suport social, psicològic i acompanyament en càncer. Servei extern amb cobertura territorial; confirmar circuit concret per a Salt.',
          nota="Desagregació del node antic T17. Les relacions amb CAP sustentades només en la memòria interna no s'han verificat de nou.")
add_actor('T26','T32',nom='Fundació Utopia',
          font_url='https://entitats.salt.cat/entitat/fundaci%c2%a2-privada-utopia/',
          claus_fonts='AP26_19',data_font='base rebuda: consulta 2026-10-07',
          web_contacte_public='https://entitats.salt.cat/entitat/fundaci%c2%a2-privada-utopia/',
          rol_potencial='Entitat del registre municipal; activitat comunitària operativa i contacte a confirmar.',
          nota="Desagregació de T26 a partir de la font del ZIP. No s'atribueix a Utopia la participació de Resilis a la Taula d'Acollida.",
          estat_verificacio='registre heretat; activitat local a validar',fonts_revisades=[],revisio_actual='')

def new_resource(id,nom,esfera,ambit,src,role,note,address='-',kind='programa'):
    add_actor('E10',id,nom=nom,esfera=esfera,ambit=ambit,tipus_alberich='rectangle',nivell='tècnic',
              cobertura='municipal',zona_barri='-',adreca=address,lat='',lon='',precisio_geo='',
              web_contacte_public=src,font_url=src,claus_fonts='REV_20261008',data_font='consulta 2026-10-08; data de publicació a Fonts i revisió',
              rol_potencial=role,nota=note,estat_verificacio='verificat',categoria_node=kind,
              cap_proximitat='no assignat',vistes='GE')
new_resource('E44','Tallers d’Acollida Lingüística i Cultural (TALC) 2026-2027','Educació','acollida/llengua',TALC,
             'Formació gratuïta de català amb inscripció prèvia, organitzada per Càritas Salt. Calendari anunciat: del 28/09/2026 al 16/06/2027, dilluns i dimecres de 9.30 a 11 h.',
             'La inscripció ordinària de setembre ja ha passat. Consultar places i possibilitat d’incorporació amb Càritas abans de proposar aquest recurs.', 'C/ Llarg, 56, Salt (locals parroquials Sant Cugat)')
new_resource('E45','Mentoria social – Projecte Rossinyol','Educació','mentoria/inclusió',ROSS,
             'Mentoria socioeducativa per a infants i adolescents, amb estudiants de la UdG. Porta d’entrada municipal per potenciar vincles, orientació i oportunitats.',
             'La pàgina descriu una cohort de 10 alumnes de secundària; no s’utilitza com a nombre de places disponibles el curs 2026-27. Confirmar selecció i calendari amb Educació.')
new_resource('E46','Tallers de Suport i Acompanyament Educatiu (TSAE)','Educació','suport educatiu/extraescolars',TSAE,
             'Suport educatiu fora de l’horari lectiu, vinculat al Pla Educatiu d’Entorn: estudi, llengua i activitats formatives. Possible aliat per treballar vinculació escolar.',
             'Programa al catàleg municipal. Confirmar places, grups, agents gestors i circuit amb cada centre el curs 2026-27.')
new_resource('E47','Kayak a l’Aula','Educació','esport/educació',KAYAK,
             'Iniciativa municipal de piragüisme i valors a l’aire lliure, adreçada a sisè de primària dels centres que hi participin.',
             'Recurs al catàleg municipal. La fitxa de 2023 no acredita per si sola calendari, inscripcions ni places del curs 2026-27.')
new_resource('E48','Neda a l’escola','Educació','esport/educació',EDU,
             'Programa inclòs al catàleg municipal de projectes educatius. Pot connectar escola, activitat física i accés a l’entorn aquàtic.',
             'Verificada la presència al catàleg, però no s’ha pogut llegir la fitxa detallada. Edats, gestió, places, accessibilitat i calendari pendents; no s’atribueix a cap gestor concret.')
new_resource('SS31','Punt d’Assessorament Energètic municipal (Social House)','Serveis municipals i socials','habitatge/pobresa energètica',APORTA,
             'Recurs descrit per CONFAVC el juliol de 2026. A-Porta acompanya el veïnat en la preparació de documentació abans de la cita d’assessorament energètic.',
             'No se n’ha acreditat adreça d’atenció, horari ni canal de cita actual. Confirmar amb l’Ajuntament o A-Porta; no confondre amb entitats homònimes.',kind='servei')
for id in ['E45','E46','E47','E48']:
    byid[id]['estat_verificacio']='oferta documentada; curs actual a confirmar'
byid['SS31']['estat_verificacio']='servei documentat; accés actual a confirmar'

for r in R:
    if 'T17' in (r['origen'],r['desti']) and ('AECC' in r['evidencia'] or 'Associació contra el Càncer' in r['evidencia']):
        for k in ['origen','desti']:
            if r[k]=='T17':r[k]='T31'
        changes.append(dict(tipus='relacio',id=r['origen']+'-'+r['desti'],motiu='Atribució a AECC segons el text de la font; no a Oncolliga.',data=TODAY))
        if 'SAFIS' in r['evidencia']:
            r['font_url']=SAFIS;r['revisio_actual']=TODAY
    if 'T26' in (r['origen'],r['desti']) and r['classe'].startswith('estructural'):
        r['estat']="hipòtesi a validar amb l'equip"
        r['evidencia'] += ' | Revisió: compartir domini de correu no acredita per si sol una relació institucional. Validar després de desagregar Utopia i Resilis.'
    if 'E09' in (r['origen'],r['desti']):
        r['estat']="hipòtesi a validar amb l'equip"

def relation(a,b,src,evidence,kind='feble',cls='funcional'):
    found=next((r for r in R if {r['origen'],r['desti']}=={a,b}),None)
    if found:
        found.update(font_url=src,evidencia=evidence,estat='documentada',revisio_actual=TODAY,data_font='consulta '+TODAY)
        changes.append(dict(tipus='relacio_revisada',id=a+'-'+b,motiu=evidence,font=src,data=TODAY))
    else:
        R.append(dict(origen=a,desti=b,tipus_relacio=kind,estat='documentada',classe=cls,evidencia=evidence,font_url=src,data_font='consulta '+TODAY,revisio_actual=TODAY))
        changes.append(dict(tipus='nova_relacio',id=a+'-'+b,motiu=evidence,font=src,data=TODAY))

for id in ['T01','T02','T03','T04','T05','T06','T07','T08','T26','C16','C23']:
    relation(id,'SS26',ACOLL,"L'article de Resilis del 25/02/2026 inclou aquesta entitat entre les participants de la Taula d'Acollida. Acredita participació a la taula, no relació bilateral amb totes les membres.")
relation('E43','C16',SALT,"Salt'Educa indica que es reuneix en assemblea a l'Ateneu de la Coma Cros.",cls='estructural (espai de trobada)')
relation('E10','P06',SIGUES,"El web municipal identifica Dipsalut com a impulsor de Sigues Tu.",kind='forta')
relation('S03','SS23',SAFIS,"ABS Salt consta com a col·laboradora de les SAFIS 2026. Activitat de 2026 ja celebrada; no acredita per si sola continuïtat anual.")
relation('E44','T01',TALC,'La convocatòria TALC 2026-2027 identifica Càritas Salt com a organitzadora.',kind='forta')
relation('E45','E01',ROSS,'La fitxa municipal descriu la col·laboració de l’Ajuntament en la mentoria socioeducativa / Rossinyol.')
relation('E46','E02',TSAE,'Els tallers s’emmarquen en el PMOE vinculat al Pla Educatiu d’Entorn.',kind='forta')
relation('E47','E01',KAYAK,'Kayak a l’Aula es presenta com a iniciativa municipal adreçada als centres de primària.')
relation('E48','E01',EDU,'Neda a l’escola figura al catàleg de projectes del Departament d’Educació municipal; abast operatiu a confirmar.')
relation('SS31','C23',APORTA,'CONFAVC descriu treball conjunt d’A-Porta amb el Punt d’Assessorament Energètic: preparació de documentació i formularis abans de la cita.',kind='forta')

def urls(text):return list(dict.fromkeys(re.findall(r'https?://[^\s|<>]+', text or '')))
def hav(lon,lat,c):
    x,y=map(math.radians,[lat,c[1]]);dl=math.radians(lon-c[0]);dp=x-y
    return round(6371000*2*math.asin(math.sqrt(math.sin(dp/2)**2+math.cos(x)*math.cos(y)*math.sin(dl/2)**2)))
def within(lon,lat):
    def ring(poly):
        inside=False;j=len(poly)-1
        for i in range(len(poly)):
            x,y=poly[i][:2]; xx,yy=poly[j][:2]
            if (y>lat)!=(yy>lat) and lon<(xx-x)*(lat-y)/(yy-y)+x:inside=not inside
            j=i
        return inside
    for f in terme['features']:
        g=f['geometry'];polys=[g['coordinates']] if g['type']=='Polygon' else g['coordinates']
        if any(ring(p[0]) and not any(ring(h) for h in p[1:]) for p in polys):return True
    return False
terme=json.loads((ROOT/'data/terme_municipal.geojson').read_text())
sec=json.loads((ROOT/'data/seccions_ist.geojson').read_text())
for a in A:
    a['urls']=urls(a['font_url'])
    a['font_interna']=bool(re.search('Memòria anual|comunicació personal|Foto sociograma',a['font_url']))
    a['fonts_revisades']=a.get('fonts_revisades',[])
    a['revisio_actual']=a.get('revisio_actual','')
    a['tipus_registre']=a.get('categoria_node') or ('col·lectiu' if a['tipus_alberich']=='cercle' else 'agrupació' if re.search(r' / |Clubs esportius|altres entitats|Xarxa de farmàcies|Centres educatius de Salt|Associacions de persones migrades|Comunitats religioses',a['nom']) else 'actor o recurs')
    a['lat']=float(a['lat']) if a['lat'] else None;a['lon']=float(a['lon']) if a['lon'] else None
    a['territori']='Sense seu geolocalitzada'
    if a['lat'] is not None:
        a['territori']='Salt' if within(a['lon'],a['lat']) else 'Recurs extern per a Salt'
        d1=hav(a['lon'],a['lat'],(2.7925568,41.9744843));d2=hav(a['lon'],a['lat'],(2.7865003,41.9698869))
        a['dist_cap_m']=min(d1,d2);a['cap_mes_proper']='Salt 1' if d1<d2 else 'Salt 2'
    else:a['cap_mes_proper']='';a['dist_cap_m']=None
    a['assignacio_cap']='No determinada; la proximitat no és adscripció'
    a['necessita_validacio']=a['estat_verificacio']!='verificat' or a['font_interna'] or not a['urls']

for i,r in enumerate(R):
    r['id']='L'+str(i+1).zfill(4)
    r['origen_nom']=byid[r['origen']]['nom'];r['desti_nom']=byid[r['desti']]['nom']
    r['urls']=urls(r['font_url'])
    internal=bool(re.search('Memòria anual|comunicació personal|Foto sociograma',r['font_url']))
    r['suport']='proposta' if r['estat']!='documentada' else 'mixt' if internal and r['urls'] else 'intern' if not r['urls'] else 'public'
    r['revisio_actual']=r.get('revisio_actual','')
    r['direccional']=False
for a in A:
    a['grau_public']=sum(a['id'] in [r['origen'],r['desti']] and r['suport']=='public' and r['classe']=='funcional' for r in R)

plans=[
 dict(id='benestar',titol='Benestar emocional i convivència',poblacio='Infants, adolescents i famílies',objectiu='Acordar un circuit compartit escola–CAP i una activitat pilot de convivència amb participació de l’alumnat.',actors=['S08','S06','E05','E43','E42','E10','E08','E09','T02','C30'],passos=['Reunió amb direcció de dos centres, referent Salut i Escola, RBEC i representants de famílies i alumnat.','Contrastar programes ja existents i barreres de participació. Confirmar si es fa servir BULL-S i amb quina finalitat.','Codissenyar quatre sessions i acordar el circuit de resposta davant detecció de malestar o assetjament.'],indicadors=['Centres i col·lectius representats en el disseny','Participants únics i continuïtat entre sessions','Percentatge que coneix on demanar ajuda abans/després'],validar='BULL-S no consta com a implantat; confirmar programes 2026-27 i responsables. Sense dades individuals d’alumnes al mapa.'),
 dict(id='acollida',titol='Acollida i accés als recursos',poblacio='Veïnat nouvingut i persones amb barreres lingüístiques',objectiu='Fer més fàcil conèixer i utilitzar els recursos del barri, amb les persones destinatàries.',actors=['SS26','SS10','T26','T03','T05','T01','C23','S07','SS21','MG00','R00'],passos=['Portar a la Taula d’Acollida dues barreres concretes detectades pel CAP i escoltar veïnat no vinculat a entitats.','Acordar mediació lingüística, espai i horari; preparar una ruta curta de recursos amb acompanyament.','Fer retorn amb participants i comprovar l’accés efectiu als recursos als 30 dies.'],indicadors=['Persones que participen en el codisseny','Participants que accedeixen a un recurs acordat','Barreres identificades i resoltes'],validar='Places i horaris de TALC; continuïtat d’A-Porta després de setembre; cap derivació nominal sense circuit acordat.'),
 dict(id='soledat',titol='Vincles i soledat no volguda',poblacio='Persones grans i persones amb poca xarxa de suport',objectiu='Crear un grup petit de trobada i activitat de proximitat connectat als recursos existents.',actors=['SS02','SS29','SS17','SS18','G01','G02','T01','T27','C24','S07','S41'],passos=['Acordar una porta d’entrada amb serveis socials i escoltar persones que no participen en casals.','Programar sis trobades accessibles combinant conversa, passeig adaptat i activitat escollida pel grup.','Revisar assistència, pertinença percebuda i continuïtat amb un recurs comunitari.'],indicadors=['Participants únics i assistència mantinguda','Canvi en la percepció de suport (autoinforme breu)','Persones que continuen en una activitat comunitària'],validar='Continuïtat i circuit d’Envelliment Km0 i Taula de Soledat; disponibilitat d’acompanyament i transport.'),
 dict(id='moviment',titol='Activitat física accessible',poblacio='Adults i persones amb barreres per fer activitat física',objectiu='Codissenyar un itinerari i un grup de moviment accessibles des de tots dos CAP.',actors=['S01','S02','S41','S10','SS23','T22','D05','S30','C24','D04'],passos=['Revisar oferta existent de SAFIS i agents esportius; seleccionar un espai accessible amb veïnat.','Acordar dos punts de trobada, ritmes i alternatives per a mobilitat reduïda.','Fer un pilot de vuit setmanes i retornar resultats a participants i entitats.'],indicadors=['Participants nous respecte a activitats prèvies','Assistència a les vuit setmanes','Barreres d’accessibilitat detectades i resoltes'],validar='No extrapolar les distàncies en línia recta a temps a peu. Confirmar programa regular més enllà de SAFIS.'),
 dict(id='families',titol='Criança i alimentació en família',poblacio='Famílies amb infants, incloses les no escolaritzades de 0-3 anys',objectiu='Preparar tallers pràctics de criança i alimentació assequible amb famílies i recursos de suport.',actors=['SS03','SS27','S09','S42','S43','T02','T01','SS06','E13','E15','E16','C20'],passos=['Escoltar necessitats i horaris a través de famílies, SOAF i escoles bressol.','Dissenyar tres tallers pràctics amb materials accessibles i espai per als infants.','Avaluar utilitat, canvis factibles i accés als suports disponibles.'],indicadors=['Famílies que participen en el disseny','Assistència de famílies amb infants no escolaritzats','Utilitat percebuda i canvi acordat als 30 dies'],validar='Accés, places, costos, idiomes i conciliació; confirmar grupals del CAP descrites només a la base interna.'),
 dict(id='joves',titol='Joves, oportunitats i comunitat',poblacio='Joves en transició educativa o laboral',objectiu='Vincular orientació, benestar i una proposta comunitària triada pels joves.',actors=['SS30','E04','SS19','SS24','C30','T06','T07','T04','E43','S34','X01'],passos=['Acordar amb la Taula FiL com arribar als joves que no utilitzen serveis.','Crear amb joves una sessió oberta de recursos i una activitat d’interès compartit.','Fer seguiment voluntari del vincle amb orientació o formació i recollir retorn.'],indicadors=['Joves fora dels circuits habituals que participen','Connexions efectives amb recursos d’orientació','Propostes dels joves que es duen a terme'],validar='Referents i circuit FiL actuals, requisits d’edat i oferta vigent dels programes.')
]
for p in plans:p['estat']='Proposta de treball; pendent de codisseny i acord';p['horitzo']='Pilot orientatiu de 8–12 setmanes'
next(p for p in plans if p['id']=='acollida')['actors'] += ['E44','SS31']
next(p for p in plans if p['id']=='joves')['actors'] += ['E45','E46']

meta=dict(titol='Sociograma comunitari de Salt',versio='2.0',data_revisio=TODAY,
          abast='Municipi de Salt i recursos que donen servei a la població urbana de CAP Salt 1 i CAP Salt 2. Els consultoris d’Aiguaviva, Vilablareix, Fornells i Bescanó queden fora de l’àmbit.',
          delimitacio='No hi ha una delimitació intra-ABS validada entre els dos CAP. No s’han dibuixat àrees d’adscripció. Les distàncies només són orientatives.',
          base='ZIP de treball 08/10/2026 (259 fitxes, 478 relacions) i còpia local visor_sociograma_salt_2026.zip per a cartografia i biblioteques.',
          actualitzacio='Revisió selectiva de fonts públiques el 08/10/2026. La resta de registres conserva la traçabilitat i la data de la base; no es presenta com a verificació exhaustiva.',
          cobertura='Actors, serveis, programes, instruments i col·lectius: el recompte de fitxes no equival a un cens d’entitats. L’annex preserva 204 entrades del registre municipal rebut.',
          cartografia='Seccions INE 2023 i IST 2023 heretats del visor. La sèrie 2024 provisional es conserva només al fitxer font; no s’etiqueta com a dada actual de 2026.',
          limitacio='Les memòries internes i comunicacions personals citades a la base no s’han aportat ni verificat en aquesta revisió. No es dedueix absència de relació quan no hi ha evidència pública.')
D=dict(meta=meta,actors=A,relacions=R,fonts=F,fonts_revisades=fresh,registre=registry,canvis=changes,plans=plans,terme=terme,seccions=sec)
for name, data in [('actors',A),('relacions',R),('fonts',F),('revisio',fresh),('canvis',changes),('plans',plans)]:
    (ROOT/'data'/f'{name}.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
(ROOT/'data/dades.js').write_text('window.DADES='+json.dumps(D,ensure_ascii=False).replace('</','<\\/')+';\n')
def savecsv(name,rows):
    fields=list(dict.fromkeys(k for row in rows for k in row))
    with (ROOT/'descarregues'/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fields);w.writeheader()
        for row in rows:w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in row.items()})
for name,rows in [('actors.csv',A),('relacions.csv',R),('fonts.csv',F),('registre_entitats.csv',registry),('registre_canvis.csv',changes),('fonts_revisades_2026-10-08.csv',fresh)]:savecsv(name,rows)
assert len(byid)==len(A)
assert all(r['origen'] in byid and r['desti'] in byid for r in R)
assert all(id in byid for p in plans for id in p['actors'])
print(json.dumps(dict(fitxes=len(A),relacions=len(R),registre=len(registry),fonts_revisades=len(fresh),canvis=len(changes),geo=sum(a['lat'] is not None for a in A),suport={s:sum(r['suport']==s for r in R) for s in ['public','mixt','intern','proposta']}),ensure_ascii=False))
