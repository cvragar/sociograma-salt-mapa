// Logic and DOM integration test doubles; these do not claim browser visual QA.
var window=globalThis;
var console={warn(){},error(){},log(){}};
var nodes=new Map(),handlers={},created=[],frames=[],frameId=0;
function element(id){if(nodes.has(id))return nodes.get(id);let cl=new Set();let e={id,innerHTML:'',textContent:'',value:'',hidden:false,dataset:{},style:{},checked:false,clientWidth:850,clientHeight:650,children:[],attributes:{},classList:{add(...x){x.forEach(v=>cl.add(v))},remove(...x){x.forEach(v=>cl.delete(v))},toggle(x,b){if(b===undefined)b=!cl.has(x);b?cl.add(x):cl.delete(x);return b},contains(x){return cl.has(x)}},addEventListener(k,f){this['on'+k]=f},setAttribute(k,v){this.attributes[k]=v},focus(){},select(){},append(x){this.children.push(x)},remove(){this.removed=true},click(){if(this.onclick)this.onclick({target:this})},showModal(){},close(){},matches(){return false},querySelector(s){return element(id+' '+s)},getBoundingClientRect(){return {left:0,top:0}},setPointerCapture(){},hasPointerCapture(){return false},releasePointerCapture(){}};nodes.set(id,e);return e}
var document={querySelector:element,querySelectorAll:()=>[],addEventListener:(k,f)=>handlers[k]=f,createElement:t=>{let e=element('created'+created.length);created.push(e);return e},body:element('body')};
var location={hash:'',href:'https://example.test/sociograma-salt/'};var history={replaceState:(a,b,c)=>location.hash=c};
var store={};var localStorage={getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=v};var navigator={clipboard:{writeText:()=>Promise.resolve()}};
function requestAnimationFrame(f){frames.push(f);return ++frameId}function flushFrames(){let count=0;while(frames.length){frames.shift()();if(++count>500)throw Error('render loop')}}
function setTimeout(){return 1}function clearTimeout(){}function matchMedia(){return {matches:false}}function addEventListener(){}
class URLSearchParams{constructor(str=''){this.m=new Map(str.split('&').filter(Boolean).map(v=>v.split('=').map(decodeURIComponent)))}get(k){return this.m.get(k)||null}has(k){return this.m.has(k)}set(k,v){this.m.set(k,String(v))}toString(){return [...this.m].map(([k,v])=>encodeURIComponent(k)+'='+encodeURIComponent(v)).join('&')}}
load('data/dades.js');
load('raster-map.js');
load('lib/cytoscape.min.js');
var realCytoscape=cytoscape;window.cytoscape=function(opts){return realCytoscape({...opts,headless:true,container:undefined,styleEnabled:false})};
load('app.js');
flushFrames();
var checks=[];function assert(v,m){if(!v)throw Error(m);checks.push(m)}
function click(data){let b={dataset:data};handlers.click({target:{closest:()=>b}});flushFrames()}
const API=SaltApp,d=API.data,s=API.getState(),M=SaltMercator;
assert(API.filterActors().length===267,'267 fichas conservadas');
assert(new Set(d.actors.map(a=>a.id)).size===267,'IDs únicos');
const ids=new Set(d.actors.map(a=>a.id));
assert(d.relacions.every(r=>ids.has(r.origen)&&ids.has(r.desti)),'495 relaciones sin extremos inexistentes');
assert(new Set(d.relacions.map(r=>[r.origen,r.desti].sort().join('|'))).size===495,'sin duplicados de relación');
assert(s.internal&&s.structural&&s.proposals,'las conexiones existentes no se ocultan al iniciar');
assert(API.networkData().focus==='S04'&&API.networkData().rr.length===19,'red inicial centrada en comunitaria del CAP');
assert(element('#map').innerHTML.includes('raster-tiles'),'mapa raster inicializado sin WebGL');
assert(created.some(e=>String(e.src).startsWith('https://tile.openstreetmap.org/')),'el mapa pide teselas reales de OpenStreetMap');
assert(element('#map svg').innerHTML.includes('Salt 1')&&element('#map svg').innerHTML.includes('Salt 2'),'ambos CAP dibujados desde sus coordenadas');
assert(API.features().some(g=>g.actors.some(a=>a.id==='S01')&&g.actors.some(a=>a.id==='S03')),'recursos coincidentes accesibles en un grupo');
for(const z of [10,14.6,19]){let p=M.project(2.7925568,41.9744843,z),r=M.unproject(...p,z);assert(Math.abs(r[0]-2.7925568)<1e-9&&Math.abs(r[1]-41.9744843)<1e-9,'proyección e inversa Web Mercator a zoom '+z)}
const tiles=M.tileCoverage([2.7893,41.974],14.6,850,650);
assert(tiles.length>4&&tiles.length<30,'solo se solicitan teselas del encuadre visible');
const cover=(x,y)=>tiles.some(t=>x>=t.x&&y>=t.y&&x<t.x+t.size&&y<t.y+t.size);
assert([[0,0],[849,0],[0,649],[849,649],[425,325]].every(p=>cover(...p)),'la base cubre todo el encuadre sin huecos de cálculo');
// Exercise the real raster engine with fake DOM nodes: pan, anchor zoom, resize and retry.
let statuses=[],rm=new SaltRasterMap(element('testMap'),{onStatus:r=>statuses.push(r)});flushFrames();
let p0=rm.project([2.7925568,41.9744843]);rm.pan(60,-35);flushFrames();let p1=rm.project([2.7925568,41.9744843]);
assert(Math.abs(p1.x-p0.x-60)<1e-7&&Math.abs(p1.y-p0.y+35)<1e-7,'puntos y calles se desplazan juntos');
let before=rm.project([2.7925568,41.9744843]);rm.zoomAt(rm.getZoom()+1,before.x,before.y);flushFrames();let after=rm.project([2.7925568,41.9744843]);
assert(Math.abs(after.x-before.x)<1e-7&&Math.abs(after.y-before.y)<1e-7,'zoom mantiene la coordenada bajo el cursor');
rm.el.clientWidth=390;rm.el.clientHeight=740;rm.resize();flushFrames();
assert(rm.width===390&&rm.height===740&&rm.svg.attributes.viewBox==='0 0 390 740','el mapa reajusta tamaño y proyección al estrecharse');
let tile=rm.tiles.get(rm.visible[0].key);tile.onerror();assert(statuses.at(-1).failed===1,'fallos de teselas visibles al usuario');rm.retry();flushFrames();assert(rm.tiles.get(rm.visible[0].key)!==tile,'reintento de teselas fallidas');
for(const t of rm.visible)rm.tiles.get(t.key).onload();assert(statuses.at(-1).loaded===rm.visible.length,'estado de carga distingue mapa completo');
click({view:'xarxa'});element('#network-reset').onclick();flushFrames();
let full=API.networkData();assert(full.rr.length===495&&full.aa.length===260&&full.unlinked.length===7,'red completa: 495 vínculos, 260 fichas conectadas y 7 pendientes aparte');
assert(full.aa.every(a=>full.rr.some(r=>r.origen===a.id||r.desti===a.id)),'ninguna ficha se dibuja desconectada');
s.internal=false;s.structural=false;s.proposals=false;let old=API.networkData();assert(old.unlinked.length===101&&old.rr.length===245,'reproduce el defecto original de 101 fichas aisladas por filtros');
click({action:'all-links'});assert(API.networkData().unlinked.length===7,'restaurar vínculos repara la desconexión causada por filtros');
click({quick:'educacio'});let edu=API.networkData();assert(API.filterActors().every(a=>a.esfera==='Educació'),'filtro educativo conserva su significado');
assert(edu.context>0&&edu.rr.every(r=>d.actors.some(a=>a.esfera==='Educació'&&(a.id===r.origen||a.id===r.desti))),'filtro educativo conserva vínculos con otros ámbitos');
click({focus:'E43'});assert(API.networkData().rr.length===19,'SaltEduca mantiene sus 19 conexiones');
assert(API.networkData().rr.every(r=>r.origen==='E43'||r.desti==='E43'),'exploración centrada: solo vínculos directos');
click({focus:'E09'});assert(API.networkData().rr.length===2&&API.networkData().rr.every(r=>r.suport==='proposta'),'BULL-S conectado como hipótesis, sin inventar implantación');
click({focus:'T17'});assert(API.networkData().aa.length===0&&element('#network-gaps').innerHTML.includes('Encara no hi ha cap relació'),'ausencia real de datos explicada sin dibujar falso aislamiento');
click({open:'S01'});assert(element('#drawer').innerHTML.includes('Situa al mapa'),'ficha permite regresar a su ubicación');
click({mapActor:'S01'});assert(s.view==='mapa'&&API.mapContext().rel.length>0&&element('#map svg').innerHTML.includes('stroke-opacity=".8"'),'selección enlaza ficha, mapa y relaciones');
click({action:'clear-selection'});assert(!s.selected&&!element('#map svg').innerHTML.includes('stroke-opacity=".8"'),'quitar selección recupera mapa general');
click({action:'reset'});s.q="SaltT'educa";assert(API.filterActors().some(a=>a.id==='E43'),'alias SaltT educa');s.q='bull-s';assert(API.filterActors().some(a=>a.id==='E09'),'búsqueda BULL-S');s.q='';
click({add:'E09'});assert(JSON.parse(store['salt-sociograma-pla-v2']).actors.includes('E09'),'planificador preservado');
click({view:'directori'});assert(element('#directory-content').innerHTML.includes('Registre municipal complementari'),'anexo del registro preservado');
assert(API.csv([{name:'=1+1'}]).includes("'=1+1"),'exportación CSV segura');
JSON.stringify({result:'PASS',checks:checks.length,actors:267,relations:495,old_false_isolates:101,full_unlinked:7,tests:checks});
