"""Execute real app logic / raster projection in JavaScriptCore. No browser automation."""
from pathlib import Path
import ctypes,json,hashlib,re
P=Path(__file__).resolve().parents[1]
j=ctypes.CDLL('/System/Library/Frameworks/JavaScriptCore.framework/JavaScriptCore'); ptr=ctypes.c_void_p
signatures={'JSGlobalContextCreate':([ptr],ptr),'JSStringCreateWithUTF8CString':([ctypes.c_char_p],ptr),'JSCheckScriptSyntax':([ptr,ptr,ptr,ctypes.c_int,ctypes.POINTER(ptr)],ctypes.c_bool),'JSEvaluateScript':([ptr,ptr,ptr,ptr,ctypes.c_int,ctypes.POINTER(ptr)],ptr),'JSValueToStringCopy':([ptr,ptr,ctypes.POINTER(ptr)],ptr),'JSStringGetMaximumUTF8CStringSize':([ptr],ctypes.c_size_t),'JSStringGetUTF8CString':([ptr,ctypes.c_char_p,ctypes.c_size_t],ctypes.c_size_t)}
for name,(args,ret) in signatures.items():getattr(j,name).argtypes=args;getattr(j,name).restype=ret
ctx=j.JSGlobalContextCreate(None)
def jsstr(s):return j.JSStringCreateWithUTF8CString(s.encode())
def text(v):
 st=j.JSValueToStringCopy(ctx,v,None);buf=ctypes.create_string_buffer(j.JSStringGetMaximumUTF8CStringSize(st));j.JSStringGetUTF8CString(st,buf,len(buf));return buf.value.decode()
for name in ['app.js','raster-map.js','data/dades.js']:
 exc=ptr();ok=j.JSCheckScriptSyntax(ctx,jsstr((P/name).read_text()),None,1,ctypes.byref(exc));assert ok,name+': '+text(exc)
script=(P/'scripts/check.js').read_text()
script=re.sub(r"load\('([^']+)'\);",lambda m:(P/m[1]).read_text(),script)
exc=ptr();v=j.JSEvaluateScript(ctx,jsstr(script),None,None,1,ctypes.byref(exc))
assert not exc.value,text(exc)
result=json.loads(text(v))
expected={'actors.json': '42fe97d86bbf3520744f29373b09d07c23c9e1007549a887b4da3581b4e50399', 'relacions.json': '3e81e17c0de9e8a599a15dad29d0d25cc7d9355eadbd2f245d40f4739c38ebb7', 'dades.js': '7d5a210f3f492b88e3bfda2ba6419437b5a06d75e05e20a7bd007ab3a15d828d'}
result['source_data_unchanged']=all(hashlib.sha256((P/'data'/f).read_bytes()).hexdigest()==sha for f,sha in expected.items())
assert result['source_data_unchanged']
result['browser_visual_validation']='Not performed: browser permission and local-preview restrictions.'
result['published_site']='Not modified'
(P/'VALIDACION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False,indent=2))
